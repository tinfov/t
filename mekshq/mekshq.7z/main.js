

/* Minit: https://demo.mekshq.com/typology/wp-content/plugins/meks-exit-popup/assets/js/modal.js */
(function($) {

    $(document).ready(function() {


        var mks_ep_modal_displayed = false;

        /* Modal open manually helper */
        $('body').on('click', '.mks-ep-trigger-open', function(e) {
            e.preventDefault();
            mks_ep_open_modal($('.mks-ep-modal'), 'click-customizer');
            mks_ep_modal_displayed = true;
        });

        if (mks_ep_can_display_modal()) {

            /* Exit trigger */
            $(document).on('mouseleave', function(e) {
                if (!mks_ep_modal_displayed && (e.pageY - $(window).scrollTop()) < 0) {
                    mks_ep_open_modal($('.mks-ep-modal'), 'exit-demo');
                    mks_ep_modal_displayed = true;
                }
            });
        }

        /* Modal close */
        $('.mks-ep-modal').on('click', 'a.mks-ep-close-modal', function(e) {
            e.preventDefault();
            mks_ep_close_modal($(this).closest('.mks-ep-modal'));
        });
   
    });

    /* Check if we modal should be displayed */
    function mks_ep_can_display_modal() {

        if (!mks_ep_is_desktop() ||  !$('.mks-ep-modal').length || mks_ep_read_cookie('mks_exit_' + $('.mks-ep-test-drive-theme').val())) {
            return false;
        }


        return true;

    }


    /* Close modal */
    function mks_ep_close_modal(obj) {
        obj.removeClass('active');
        $('body, html').removeClass('mks-ep-modal-open');
    }



    /* Open modal */
    function mks_ep_open_modal(obj, ref) {

        var window_height = $(window).height();

        obj.css('height', window_height + 'px').css('top', $(window).scrollTop() + 'px').addClass('active');

        $('body, html').addClass('mks-ep-modal-open');
        $('.mks-ep-modal-test-drive-response').hide();
        $('.mks-ep-modal-test-drive-request').show();

        //mks_ep_center(obj.find('.mks-ep-section'));

        $('.mks-ep-test-drive-ref').val(ref);

        var cookie_name = 'mks_exit_' + obj.find('.mks-ep-test-drive-theme').val();

        if (!mks_ep_read_cookie(cookie_name)) {
            mks_ep_create_cookie(cookie_name, true, 30);
        }

    }




    /* Check if is desktop */
    function mks_ep_is_desktop() {

        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            return false;
        }

        return true;
    }


    /* Create cookie */
    function mks_ep_create_cookie(name, value, days) {
        var expires;

        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toGMTString();
        } else {
            expires = "";
        }
        document.cookie = encodeURIComponent(name) + "=" + encodeURIComponent(value) + expires + "; path=/";
    }


    /* Read/check cookie */
    function mks_ep_read_cookie(name) {
        var nameEQ = encodeURIComponent(name) + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) === ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) === 0) return decodeURIComponent(c.substring(nameEQ.length, c.length));
        }
        return null;
    }





})(jQuery);



/* Minit */
(function($) {
    $(document).ready(function($) {

        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {

            $("body").on("touchstart", ".mks_accordion_heading", function(e) {
                mks_accordion_handle($(this));
            });

            $("body").on("touchstart", ".mks_toggle_heading", function(e) {
                mks_toggle_handle($(this));
            });


            $("body").on("touchstart", ".mks_tabs_nav .mks_tab_nav_item", function(e) {
                mks_tab_handle($(this));
            });

        } else {

            $("body").on("click", ".mks_accordion_heading", function(e) {
                mks_accordion_handle($(this));
            });


            $("body").on("click", ".mks_toggle_heading", function(e) {
                mks_toggle_handle($(this));
            });


            $("body").on("click", ".mks_tabs_nav .mks_tab_nav_item", function(e) {
                mks_tab_handle($(this));
            });
        }

        /* Initialize tabs */
        $('.mks_tabs').each(function() {

            var tabs_nav = $(this).find('.mks_tabs_nav');

            $(this).find('.mks_tab_item').each(function() {
                tabs_nav.append('<div class="mks_tab_nav_item">' + $(this).find('.nav').html() + '</div>');
                $(this).find('.nav').remove();

            });

            $(this).find('.mks_tabs_nav').find('.mks_tab_nav_item:first').addClass('active');
            $(this).find('.mks_tab_item').hide();
            $(this).find('.mks_tab_item:first').show();
            $(this).show();

        });
        
        $('body').on('click', '.meks_ess-item:not(".prevent-share-popup")', function(e) {
            e.preventDefault();
            meks_ess_popup($(this).attr('data-url'));
        });


    });

    function mks_accordion_handle($obj) {
        var toggle = $obj.parent('.mks_accordion_item');
        if (!toggle.hasClass('mks_accordion_active')) {
            toggle.parent('div').find('.mks_accordion_item').find('.mks_accordion_content:visible').slideUp("fast");
            toggle.parent('div').find('.mks_accordion_active').removeClass('mks_accordion_active');
            toggle.find('.mks_accordion_content').slideToggle("fast", function() {
                toggle.addClass('mks_accordion_active');
                if ((toggle.offset().top + 100) < $(window).scrollTop()) {
                    $('html, body').stop().animate({
                        scrollTop: (toggle.offset().top - 100)
                    }, '300');
                }
            });
        } else {
            toggle.parent('div').find('.mks_accordion_item').find('.mks_accordion_content:visible').slideUp("fast");
            toggle.parent('div').find('.mks_accordion_active').removeClass('mks_accordion_active');
        }
    }

    function mks_toggle_handle($obj) {
        var toggle = $obj.parent('.mks_toggle');
        toggle.find('.mks_toggle_content').slideToggle("fast", function() {
            toggle.toggleClass('mks_toggle_active');
        });
    }

    function mks_tab_handle($obj) {
        if ($obj.hasClass('active') == false) {

            tab_to_show = $obj.parent('.mks_tabs_nav').find('.mks_tab_nav_item').index($obj);

            $obj.parent('.mks_tabs_nav').parent('.mks_tabs').find('.mks_tab_item').hide();
            $obj.parent('.mks_tabs_nav').parent('.mks_tabs').find('.mks_tab_item').eq(tab_to_show).show();

            $obj.parent('.mks_tabs_nav').find('.mks_tab_nav_item').removeClass('active');
            $obj.addClass('active');

        }
    }

    function meks_ess_popup(data) {
        window.open(data, "Share", 'height=500,width=760,top=' + ($(window).height() / 2 - 250) + ', left=' + ($(window).width() / 2 - 380) + 'resizable=0,toolbar=0,menubar=0,status=0,location=0,scrollbars=0');
    }
    
    
})(jQuery);



/* Minit min.js */

/* js file */

!function(t){"use strict";t.fn.fitVids=function(e){var i={customSelector:null,ignore:null};if(!document.getElementById("fit-vids-style")){var r=document.head||document.getElementsByTagName("head")[0],a=".fluid-width-video-wrapper{width:100%;position:relative;padding:0;}.fluid-width-video-wrapper iframe,.fluid-width-video-wrapper object,.fluid-width-video-wrapper embed {position:absolute;top:0;left:0;width:100%;height:100%;}",d=document.createElement("div");d.innerHTML='<p>x</p><style id="fit-vids-style">'+a+"</style>",r.appendChild(d.childNodes[1])}return e&&t.extend(i,e),this.each(function(){var e=['iframe[src*="player.vimeo.com"]','iframe[src*="youtube.com"]','iframe[src*="youtube-nocookie.com"]','iframe[src*="kickstarter.com"][src*="video.html"]',"object","embed"];i.customSelector&&e.push(i.customSelector);var r=".fitvidsignore";i.ignore&&(r=r+", "+i.ignore);var a=t(this).find(e.join(","));a=a.not("object object"),a=a.not(r),a.each(function(){var e=t(this);if(!(e.parents(r).length>0||"embed"===this.tagName.toLowerCase()&&e.parent("object").length||e.parent(".fluid-width-video-wrapper").length)){e.css("height")||e.css("width")||!isNaN(e.attr("height"))&&!isNaN(e.attr("width"))||(e.attr("height",9),e.attr("width",16));var i="object"===this.tagName.toLowerCase()||e.attr("height")&&!isNaN(parseInt(e.attr("height"),10))?parseInt(e.attr("height"),10):e.height(),a=isNaN(parseInt(e.attr("width"),10))?e.width():parseInt(e.attr("width"),10),d=i/a;if(!e.attr("name")){var o="fitvid"+t.fn.fitVids._count;e.attr("name",o),t.fn.fitVids._count++}e.wrap('<div class="fluid-width-video-wrapper"></div>').parent(".fluid-width-video-wrapper").css("padding-top",100*d+"%"),e.removeAttr("height").removeAttr("width")}})})},t.fn.fitVids._count=0}(window.jQuery||window.Zepto),

function (o, t, e, n) {
	function i(t, i) {
		var s = !1,
			e = t.charAt(0).toUpperCase() + t.slice(1);
		return o.each((t + " " + a.join(e + " ") + e).split(" "), function (t, e) {
			return r[e] !== n ? (s = !i || e, !1) : void 0
		}), s
	}

	function s(t) {
		return i(t, !0)
	}
	var r = o("<support>").get(0).style,
		a = "Webkit Moz O ms".split(" "),
		l = {
			transition: {
				end: {
					WebkitTransition: "webkitTransitionEnd",
					MozTransition: "transitionend",
					OTransition: "oTransitionEnd",
					transition: "transitionend"
				}
			},
			animation: {
				end: {
					WebkitAnimation: "webkitAnimationEnd",
					MozAnimation: "animationend",
					OAnimation: "oAnimationEnd",
					animation: "animationend"
				}
			}
		},
		c = function () {
			return !!i("transform")
		},
		h = function () {
			return !!i("perspective")
		},
		p = function () {
			return !!i("animation")
		};
	(function () {
		return !!i("transition")
	})() && (o.support.transition = new String(s("transition")), o.support.transition.end = l.transition.end[o.support.transition]), p() && (o.support.animation = new String(s("animation")), o.support.animation.end = l.animation.end[o.support.animation]), c() && (o.support.transform = new String(s("transform")), o.support.transform3d = h())
}(window.Zepto || window.jQuery, window, document),


function (e) {
	"use strict";
	e(document).ready(function () {
		e("#switcher_link, .switcher_close").click(function (t) {
			t.preventDefault(), e("#switcher_wrap").toggleClass("switcher_moved")
		}), e("#switcher_wrap").hasClass("lazy_open") && setTimeout(function () {
			e("#switcher_wrap").hasClass("switcher_moved") && e("#switcher_link").click()
		}, 7e3), e("body").on("click", ".switcher_items a", function () {
			var t = e(this).attr("data-type");
			"style" != t ? (e(".typology-switcher-" + t).remove(), "default" != e(this).attr("data-id") && e("head").append('<link media="all" type="text/css" href="' + e(this).attr("data-url") + '" class="typology-switcher-' + t + '" rel="stylesheet">')) : "flat" == e(this).attr("data-id") ? (e("body").addClass("typology-flat").css("background", "#ffffff"), e(".typology-fake-bg").css("background", "#ffffff")) : (e("body").removeClass("typology-flat").removeAttr("style"), e(".typology-fake-bg").removeAttr("style")), e(this).closest(".switcher_items").find("a").removeClass("active"), e(this).addClass("active")
		}), e("#show-rtl").change(function () {
			e(".typology-sidebar").hide(), e(this).is(":checked") ? e("head").append('<link media="all" type="text/css" href="' + e(this).attr("data-url") + '" id="typology-rtl-css-custom" rel="stylesheet">') : e("#typology-rtl-css-custom").remove(), setTimeout(function () {
				e(".typology-sidebar").show()
			}, 500)
		})
	})
}(jQuery),


function (A) {
	"use strict";
	var g = {
		settings: {
			cover_height: "auto",
			admin_bar: {
				height: 0,
				position: ""
			}
		},
		pushes: {
			url: [],
			up: 0,
			down: 0
		},
		init: function () {
			this.sidebar(), this.cover_slider(), this.reverse_menu(), this.browser_check(), this.push_state_for_loading(), this.load_more(), this.infinite_scroll(), this.accordion_widget(), this.single_sticky_bottom(), this.responsive_videos(), this.scroll_to_top(), this.scroll_down(), this.read_later(), this.scroll_to_comments(), this.logo_setup(), this.admin_bar_check(), this.cover_height(), this.gallery_slider(A(".section-content")), this.gallery_popup(A(".section-content")), this.sticky_header(), this.center_layout_items(), this.responsive_navigation(), this.video_fallback_image(), this.align_full_fix(), this.search_action_hover()
		},
		resize: function () {
			this.admin_bar_check(), this.responsive_navigation(), this.align_full_fix(), 500 < A(window).width() && this.cover_height()
		},
		admin_bar_check: function () {
			if (A("#wpadminbar").length && A("#wpadminbar").is(":visible") && (this.settings.admin_bar.height = A("#wpadminbar").height(), this.settings.admin_bar.position = A("#wpadminbar").css("position"), A(".typology-header").length)) {
				var t = "relative" != this.settings.admin_bar.position ? this.settings.admin_bar.height : 0;
				A(".typology-header").css("top", t)
			}
		},
		cover_height: function () {
			if (!A(".typology-cover-empty").length) {
				var t = A(window).height() - this.settings.admin_bar.height + Math.abs(parseInt(A(".typology-section:first").css("top"), 10)),
					e = A(".cover-item-container").height(),
					i = A(".typology-scroll-down-arrow"),
					s = A("#typology-header").height(),
					o = !0;
				t < 450 && (t = 450), t - s < e && (t = e + s + 100, o = !1), A(window).width() <= 1366 ? (this.settings.cover_height = t, A(".typology-cover-item, .typology-cover-img").css("height", t), A(".typology-cover-slider").length && A(".typology-cover-slider .owl-stage-outer").css("height", t), A(".typology-cover").css("height", t), i.length && A(".typology-cover-slider .owl-dots").hide()) : (A(".typology-cover-item").css("height", A(".typology-cover").height()), A(".typology-cover").css("height", A(".typology-cover").height()), this.settings.cover_height = A(".typology-cover").height()), o && (A(".typology-cover-slider").length ? A(".typology-slider-wrapper-fixed").css("position", "fixed") : A(".typology-cover-item").css("position", "fixed"))
			}
		},
		cover_slider: function () {
			A(".typology-cover-slider").owlCarousel({
				rtl: !!typology_js_settings.rtl_mode,
				loop: !0,
				autoHeight: !0,
				autoWidth: !1,
				items: 1,
				margin: 0,
				nav: !0,
				dots: !(0 < typology_js_settings.scroll_down_arrow),
				center: !1,
				fluidSpeed: 100,
				navText: ['<i class="fa fa-chevron-left"></i>', '<i class="fa fa-chevron-right"></i>'],
				autoplay: 0 < typology_js_settings.slider_autoplay,
				autoplayTimeout: typology_js_settings.slider_autoplay,
				autoplaySpeed: 400,
				navSpeed: 400,
				responsive: {
					0: {
						autoHeight: !1
					},
					1e3: {
						autoHeight: !0
					}
				}
			})
		},
		gallery_slider: function (t) {
			typology_js_settings.use_gallery && A("body").imagesLoaded(function () {
				t.find(".gallery-columns-1, .wp-block-gallery.columns-1").addClass("owl-carousel").owlCarousel({
					rtl: !!typology_js_settings.rtl_mode,
					loop: !0,
					nav: !0,
					autoWidth: !1,
					autoHeight: !0,
					center: !1,
					fluidSpeed: 100,
					margin: 0,
					items: 1,
					navText: ['<i class="fa fa-chevron-left"></i>', '<i class="fa fa-chevron-right"></i>']
				})
			})
		},
		gallery_popup: function (t) {
			typology_js_settings.use_gallery && t.find(".gallery, .wp-block-gallery").each(function () {
				var i = A(this),
					t = i.hasClass("wp-block-gallery") ? ".blocks-gallery-item a" : ".gallery-icon a.typology-popup";
				A(this).find(t).magnificPopup({
					type: "image",
					gallery: {
						enabled: !0
					},
					image: {
						titleSrc: function (t) {
							var e = i.hasClass("wp-block-gallery") ? t.el.closest("figure").find("figcaption") : t.el.closest(".gallery-item").find(".gallery-caption");
							return "undefined" != e ? e.text() : ""
						}
					}
				})
			})
		},
		sidebar: function () {
			var e = "typology-sidebar-open typology-lock";
			A("body").on("click", ".typology-action-sidebar", function () {
				A("body").addClass(e), A(".typology-sidebar").css("top", g.settings.admin_bar.height)
			}), A("body").on("click", ".typology-sidebar-close, .typology-sidebar-overlay", function () {
				A("body").removeClass(e)
			}), A(document).keyup(function (t) {
				27 == t.keyCode && A("body").hasClass(e) && A("body").removeClass(e)
			})
		},
		reverse_menu: function () {
			A(".typology-header").on("mouseenter", ".typology-nav li", function (t) {
				A(this).find("ul").length && (A(window).width() - (A(this).find("ul").offset().left + A(this).find("ul").outerWidth()) < 0 && A(this).find("ul").addClass("typology-rev"))
			})
		},
		logo_setup: function () {
			1 < window.devicePixelRatio && typology_js_settings.logo_retina && A(".typology-logo").length && A(".typology-logo").imagesLoaded(function () {
				A(".typology-logo").each(function () {
					if (A(this).is(":visible")) {
						var t = A(this).width();
						A(this).attr("src", typology_js_settings.logo_retina).css("width", t + "px")
					}
				})
			})
		},
		sticky_header: function () {
			var t = A(".typology-section");
			if (!t.length) return !1;
			var s = "fixed" == this.settings.admin_bar.position ? this.settings.admin_bar.height : 0,
				o = t.first().offset().top - s + Math.abs(parseInt(t.first().css("top"))) + 400,
				n = o - 400 - Math.abs(parseInt(t.first().css("top"))) - A(".typology-header").height() / 2,
				r = A(".typology-cover-empty").length ? 0 : o - 400,
				a = A(".cover-item-container"),
				l = A(".typology-scroll-down-arrow"),
				c = A(".typology-header"),
				h = 0,
				p = "down",
				d = !1,
				u = !0;
			50 < A(window).scrollTop() && u && (c.css("z-index", 1e3), u = !1), A(window).scroll(function () {
				var t = "relative" != g.settings.admin_bar.position ? g.settings.admin_bar.height : 0;
				typology_js_settings.header_sticky && (A(window).scrollTop() < o ? d && (c.animate({
					top: -70 + s
				}, 200, function () {
					A(this).removeClass("typology-header-sticky"), A(this).css("top", t), A(this).css("z-index", 1e3)
				}), d = !1) : d || (c.css("top", -70 + s).addClass("typology-header-sticky").animate({
					top: s
				}, 200), c.css("z-index", 9001), d = !0)), A(window).scrollTop() < n ? u || (c.css("z-index", 9001), u = !0) : u && (c.css("z-index", 1e3), u = !1);
				var e = 0;
				if (A(window).scrollTop() < r) {
					var i = (100 - 100 * A(window).scrollTop() / r) / 100;
					"down" === p ? e = i - .8 : A(window).scrollTop() < 150 && (e = i + .002), a.css("opacity", i), l.css("opacity", e), p = h < e ? "up" : "down", h = e
				}
			}), A.fn.scrollEnd = function (e, i) {
				A(this).scroll(function () {
					var t = A(this);
					t.data("scrollTimeout") && clearTimeout(t.data("scrollTimeout")), t.data("scrollTimeout", setTimeout(e, i))
				})
			}, A(window).scrollEnd(function () {
				A(window).scrollTop() < n ? (c.css("z-index", 9001), u = !0) : u && (c.css("z-index", 1e3), u = !1)
			}, 1e3)
		},
		accordion_widget: function () {
			A(".typology-responsive-menu .typology-nav").each(function () {
				A(this).find(".menu-item-has-children > a").after('<span class="typology-nav-widget-acordion"><i class="fa fa-angle-down"></i></span>')
			}), A("body").on("click", ".typology-responsive-menu .typology-nav-widget-acordion", function () {
				A(this).next("ul.sub-menu:first, ul.children:first").slideToggle("fast").parent().toggleClass("active")
			})
		},
		single_sticky_bottom: function () {
			if (A("#typology-single-sticky").length) {
				var t = A(".typology-single-post").offset().top + 300,
					e = A(".typology-single-post").offset().top + A(".typology-single-post").height() - A(window).height(),
					i = A("#typology-footer").offset().top - A(window).height() - 100;
				A(window).scroll(function () {
					A(window).scrollTop() > t ? A(".typology-sticky-content.meta").parent().addClass("typology-single-sticky-show typology-show-meta") : A(".typology-sticky-content.meta").parent().removeClass("typology-single-sticky-show"), A(window).scrollTop() > e ? (console.log(A(window).scrollTop()), A(".typology-sticky-content.meta").parent().removeClass("typology-show-meta"), A(window).scrollTop() < i ? A(".typology-sticky-content.prev-next").parent().addClass("typology-show-prev-next") : A(".typology-sticky-content.meta").parent().removeClass("typology-single-sticky-show typology-show-meta")) : A(".typology-sticky-content.prev-next").parent().removeClass("typology-show-prev-next")
				})
			}
		},
		responsive_videos: function () {
			A(".entry-content").fitVids({
				customSelector: ["iframe[src*='youtube.com/embed']", "iframe[src*='player.vimeo.com/video']", "iframe[src*='kickstarter.com/projects']", "iframe[src*='players.brightcove.net']", "iframe[src*='hulu.com/embed']", "iframe[src*='vine.co/v']", "iframe[src*='videopress.com/embed']", "iframe[src*='dailymotion.com/embed']", "iframe[src*='vid.me/e']", "iframe[src*='player.twitch.tv']", "iframe[src*='facebook.com/plugins/video.php']", "iframe[src*='gfycat.com/ifr/']", "iframe[src*='liveleak.com/ll_embed']", "iframe[src*='media.myspace.com']", "iframe[src*='archive.org/embed']", "iframe[src*='channel9.msdn.com']", "iframe[src*='content.jwplatform.com']", "iframe[src*='wistia.com']", "iframe[src*='vooplayer.com']", "iframe[src*='content.zetatv.com.uy']", "iframe[src*='embed.wirewax.com']", "iframe[src*='eventopedia.navstream.com']", "iframe[src*='cdn.playwire.com']", "iframe[src*='drive.google.com']", "iframe[src*='videos.sproutvideo.com']"].join(","),
				ignore: '[class^="wp-block"]'
			})
		},
		scroll_to_top: function () {
			A(".typology-sticky-to-top").length && A("body").on("click", ".typology-sticky-to-top", function (t) {
				return t.preventDefault(), A("body,html").animate({
					scrollTop: 0
				}, 800), !1
			})
		},
		scroll_down: function () {
			var e = A(".typology-section");
			if (!e.length) return !1;
			A("body").on("click", ".typology-scroll-down-arrow", function (t) {
				return t.preventDefault(), A("body,html").animate({
					scrollTop: e.offset().top
				}, 800), !1
			})
		},
		scroll_to_comments: function () {
			A("body").on("click", ".typology-single-post .meta-comments a, .typology-cover-single .meta-comments a, .typology-sticky-comments a", function (t) {
				t.preventDefault();
				var e = this.hash,
					i = A(e);
				A("html, body").stop().animate({
					scrollTop: i.offset().top - 100
				}, 800, "swing", function () {
					window.location.hash = e
				})
			})
		},
		read_later: function () {
			A("body").on("click", ".typology-rl", function (t) {
				t.preventDefault(), A(this).hasClass("pocket") && g.share_popup(A(this).attr("data-url"))
			})
		},
		center_layout_items: function () {
			A(".section-content-c .typology-posts .typology-layout-c").length % 2 != 0 ? A(".section-content-c").addClass("layout-even").removeClass("layout-odd") : A(".section-content-c").addClass("layout-odd").removeClass("layout-even")
		},
		push_state_for_loading: function () {
			if (A(".typology-pagination .load-more a").length || A(".typology-pagination .infinite-scroll").length) {
				var t = {
					prev: window.location.href,
					next: "",
					offset: A(window).scrollTop(),
					prev_title: window.document.title,
					next_title: window.document.title
				};
				g.pushes.url.push(t), window.history.pushState(t, "", window.location.href);
				var e, i = 0;
				A(window).scroll(function () {
					g.pushes.url[g.pushes.up].offset != e && A(window).scrollTop() < g.pushes.url[g.pushes.up].offset && (e = g.pushes.url[g.pushes.up].offset, i = 0, window.document.title = g.pushes.url[g.pushes.up].prev_title, window.history.replaceState(g.pushes.url, "", g.pushes.url[g.pushes.up].prev), g.pushes.down = g.pushes.up, 0 !== g.pushes.up && g.pushes.up--), g.pushes.url[g.pushes.down].offset != i && A(window).scrollTop() > g.pushes.url[g.pushes.down].offset && (i = g.pushes.url[g.pushes.down].offset, e = 0, window.document.title = g.pushes.url[g.pushes.down].next_title, window.history.replaceState(g.pushes.url, "", g.pushes.url[g.pushes.down].next), g.pushes.up = g.pushes.down, g.pushes.down < g.pushes.url.length - 1 && g.pushes.down++)
				})
			}
		},
		load_more: function () {
			var l = 0;
			A("body").on("click", ".typology-pagination .load-more a", function (t) {
				t.preventDefault();
				var n = window.location.href,
					r = window.document.title,
					e = A(this),
					a = e.attr("href");
				e.parent().addClass("load-more-active"), A("<div>").load(a, function () {
					var t = l.toString(),
						i = A(".typology-posts").last(),
						s = A(this),
						o = s.find(".typology-posts").last().children().addClass("typology-new-" + t);
					o.imagesLoaded(function () {
						if (o.hide().appendTo(i).fadeIn(400), g.center_layout_items(), s.find(".typology-pagination").length ? A(".typology-pagination").html(s.find(".typology-pagination").html()) : A(".typology-pagination").fadeOut("fast").remove(), a != window.location) {
							g.pushes.up++, g.pushes.down++;
							var t = s.find("title").text(),
								e = {
									prev: n,
									next: a,
									offset: A(window).scrollTop(),
									prev_title: r,
									next_title: t
								};
							g.pushes.url.push(e), window.document.title = t, window.history.pushState(e, "", a)
						}
						return l++, !1
					})
				})
			})
		},
		share_popup: function (t) {
			window.open(t, "Share", "height=500,width=760,top=" + (A(window).height() / 2 - 250) + ", left=" + (A(window).width() / 2 - 380) + "resizable=0,toolbar=0,menubar=0,status=0,location=0,scrollbars=0")
		},
		infinite_scroll: function () {
			if (A(".typology-pagination .infinite-scroll").length) {
				var l = !0,
					c = 0;
				A(window).scroll(function () {
					if (l && A(this).scrollTop() > A(".typology-pagination").offset().top - A(this).height() - 200) {
						l = !1;
						var n = window.location.href,
							r = window.document.title,
							t = A(".typology-pagination .infinite-scroll a"),
							a = t.attr("href");
						t.parent().addClass("load-more-active"), void 0 !== a && A("<div>").load(a, function () {
							var t = c.toString(),
								i = A(".typology-posts").last(),
								s = A(this),
								o = s.find(".typology-posts").last().children().addClass("typology-new-" + t);
							o.imagesLoaded(function () {
								if (o.hide().appendTo(i).fadeIn(400), g.center_layout_items(), s.find(".typology-pagination").length ? (A(".typology-pagination").html(s.find(".typology-pagination").html()), l = !0) : A(".typology-pagination").fadeOut("fast").remove(), a != window.location) {
									g.pushes.up++, g.pushes.down++;
									var t = s.find("title").text(),
										e = {
											prev: n,
											next: a,
											offset: A(window).scrollTop(),
											prev_title: r,
											next_title: t
										};
									g.pushes.url.push(e), window.document.title = t, window.history.pushState(e, "", a)
								}
								return c++, !1
							})
						})
					}
				})
			}
		},
		responsive_navigation: function () {
			A("#typology-header .typology-main-navigation").length && 480 < A(window).width() && (A("#typology-header .container:first").width() - 50 < (A("#typology-header .typology-site-branding").length ? A("#typology-header .typology-site-branding").width() : 0) + A("#typology-header .typology-main-navigation").width() + A("#typology-header .typology-actions-list").width() ? (A("#typology-header .typology-main-navigation").css("opacity", 0).css("position", "absolute"), A(".typology-responsive-menu").show(), A(".typology-action-sidebar.typology-mobile-visible").css({
				display: "inline-block"
			})) : (A("#typology-header .typology-main-navigation").css("opacity", 1).css("position", "relative"), A(".typology-responsive-menu").hide(), A(".typology-action-sidebar.typology-mobile-visible").css({
				display: "none"
			})))
		},
		is_autoplay_supported: function (t) {
			if ("function" != typeof t) return console.log("is_autoplay_supported: Callback must be a function!"), !1;
			if (sessionStorage.autoplay_supported) "true" === sessionStorage.autoplay_supported ? t(!0) : t(!1);
			else {
				var e = document.createElement("video");
				e.autoplay = !0, e.src = "data:video/mp4;base64,AAAAIGZ0eXBtcDQyAAAAAG1wNDJtcDQxaXNvbWF2YzEAAATKbW9vdgAAAGxtdmhkAAAAANLEP5XSxD+VAAB1MAAAdU4AAQAAAQAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAACFpb2RzAAAAABCAgIAQAE////9//w6AgIAEAAAAAQAABDV0cmFrAAAAXHRraGQAAAAH0sQ/ldLEP5UAAAABAAAAAAAAdU4AAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAoAAAAFoAAAAAAAkZWR0cwAAABxlbHN0AAAAAAAAAAEAAHVOAAAH0gABAAAAAAOtbWRpYQAAACBtZGhkAAAAANLEP5XSxD+VAAB1MAAAdU5VxAAAAAAANmhkbHIAAAAAAAAAAHZpZGUAAAAAAAAAAAAAAABMLVNNQVNIIFZpZGVvIEhhbmRsZXIAAAADT21pbmYAAAAUdm1oZAAAAAEAAAAAAAAAAAAAACRkaW5mAAAAHGRyZWYAAAAAAAAAAQAAAAx1cmwgAAAAAQAAAw9zdGJsAAAAwXN0c2QAAAAAAAAAAQAAALFhdmMxAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAoABaABIAAAASAAAAAAAAAABCkFWQyBDb2RpbmcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//AAAAOGF2Y0MBZAAf/+EAHGdkAB+s2UCgL/lwFqCgoKgAAB9IAAdTAHjBjLABAAVo6+yyLP34+AAAAAATY29scm5jbHgABQAFAAUAAAAAEHBhc3AAAAABAAAAAQAAABhzdHRzAAAAAAAAAAEAAAAeAAAD6QAAAQBjdHRzAAAAAAAAAB4AAAABAAAH0gAAAAEAABONAAAAAQAAB9IAAAABAAAAAAAAAAEAAAPpAAAAAQAAE40AAAABAAAH0gAAAAEAAAAAAAAAAQAAA+kAAAABAAATjQAAAAEAAAfSAAAAAQAAAAAAAAABAAAD6QAAAAEAABONAAAAAQAAB9IAAAABAAAAAAAAAAEAAAPpAAAAAQAAE40AAAABAAAH0gAAAAEAAAAAAAAAAQAAA+kAAAABAAATjQAAAAEAAAfSAAAAAQAAAAAAAAABAAAD6QAAAAEAABONAAAAAQAAB9IAAAABAAAAAAAAAAEAAAPpAAAAAQAAB9IAAAAUc3RzcwAAAAAAAAABAAAAAQAAACpzZHRwAAAAAKaWlpqalpaampaWmpqWlpqalpaampaWmpqWlpqalgAAABxzdHNjAAAAAAAAAAEAAAABAAAAHgAAAAEAAACMc3RzegAAAAAAAAAAAAAAHgAAA5YAAAAVAAAAEwAAABMAAAATAAAAGwAAABUAAAATAAAAEwAAABsAAAAVAAAAEwAAABMAAAAbAAAAFQAAABMAAAATAAAAGwAAABUAAAATAAAAEwAAABsAAAAVAAAAEwAAABMAAAAbAAAAFQAAABMAAAATAAAAGwAAABRzdGNvAAAAAAAAAAEAAAT6AAAAGHNncGQBAAAAcm9sbAAAAAIAAAAAAAAAHHNiZ3AAAAAAcm9sbAAAAAEAAAAeAAAAAAAAAAhmcmVlAAAGC21kYXQAAAMfBgX///8b3EXpvebZSLeWLNgg2SPu73gyNjQgLSBjb3JlIDE0OCByMTEgNzU5OTIxMCAtIEguMjY0L01QRUctNCBBVkMgY29kZWMgLSBDb3B5bGVmdCAyMDAzLTIwMTUgLSBodHRwOi8vd3d3LnZpZGVvbGFuLm9yZy94MjY0Lmh0bWwgLSBvcHRpb25zOiBjYWJhYz0xIHJlZj0zIGRlYmxvY2s9MTowOjAgYW5hbHlzZT0weDM6MHgxMTMgbWU9aGV4IHN1Ym1lPTcgcHN5PTEgcHN5X3JkPTEuMDA6MC4wMCBtaXhlZF9yZWY9MSBtZV9yYW5nZT0xNiBjaHJvbWFfbWU9MSB0cmVsbGlzPTEgOHg4ZGN0PTEgY3FtPTAgZGVhZHpvbmU9MjEsMTEgZmFzdF9wc2tpcD0xIGNocm9tYV9xcF9vZmZzZXQ9LTIgdGhyZWFkcz0xMSBsb29rYWhlYWRfdGhyZWFkcz0xIHNsaWNlZF90aHJlYWRzPTAgbnI9MCBkZWNpbWF0ZT0xIGludGVybGFjZWQ9MCBibHVyYXlfY29tcGF0PTAgc3RpdGNoYWJsZT0xIGNvbnN0cmFpbmVkX2ludHJhPTAgYmZyYW1lcz0zIGJfcHlyYW1pZD0yIGJfYWRhcHQ9MSBiX2JpYXM9MCBkaXJlY3Q9MSB3ZWlnaHRiPTEgb3Blbl9nb3A9MCB3ZWlnaHRwPTIga2V5aW50PWluZmluaXRlIGtleWludF9taW49Mjkgc2NlbmVjdXQ9NDAgaW50cmFfcmVmcmVzaD0wIHJjX2xvb2thaGVhZD00MCByYz0ycGFzcyBtYnRyZWU9MSBiaXRyYXRlPTExMiByYXRldG9sPTEuMCBxY29tcD0wLjYwIHFwbWluPTUgcXBtYXg9NjkgcXBzdGVwPTQgY3BseGJsdXI9MjAuMCBxYmx1cj0wLjUgdmJ2X21heHJhdGU9ODI1IHZidl9idWZzaXplPTkwMCBuYWxfaHJkPW5vbmUgZmlsbGVyPTAgaXBfcmF0aW89MS40MCBhcT0xOjEuMDAAgAAAAG9liIQAFf/+963fgU3DKzVrulc4tMurlDQ9UfaUpni2SAAAAwAAAwAAD/DNvp9RFdeXpgAAAwB+ABHAWYLWHUFwGoHeKCOoUwgBAAADAAADAAADAAADAAAHgvugkks0lyOD2SZ76WaUEkznLgAAFFEAAAARQZokbEFf/rUqgAAAAwAAHVAAAAAPQZ5CeIK/AAADAAADAA6ZAAAADwGeYXRBXwAAAwAAAwAOmAAAAA8BnmNqQV8AAAMAAAMADpkAAAAXQZpoSahBaJlMCCv//rUqgAAAAwAAHVEAAAARQZ6GRREsFf8AAAMAAAMADpkAAAAPAZ6ldEFfAAADAAADAA6ZAAAADwGep2pBXwAAAwAAAwAOmAAAABdBmqxJqEFsmUwIK//+tSqAAAADAAAdUAAAABFBnspFFSwV/wAAAwAAAwAOmQAAAA8Bnul0QV8AAAMAAAMADpgAAAAPAZ7rakFfAAADAAADAA6YAAAAF0Ga8EmoQWyZTAgr//61KoAAAAMAAB1RAAAAEUGfDkUVLBX/AAADAAADAA6ZAAAADwGfLXRBXwAAAwAAAwAOmQAAAA8Bny9qQV8AAAMAAAMADpgAAAAXQZs0SahBbJlMCCv//rUqgAAAAwAAHVAAAAARQZ9SRRUsFf8AAAMAAAMADpkAAAAPAZ9xdEFfAAADAAADAA6YAAAADwGfc2pBXwAAAwAAAwAOmAAAABdBm3hJqEFsmUwIK//+tSqAAAADAAAdUQAAABFBn5ZFFSwV/wAAAwAAAwAOmAAAAA8Bn7V0QV8AAAMAAAMADpkAAAAPAZ+3akFfAAADAAADAA6ZAAAAF0GbvEmoQWyZTAgr//61KoAAAAMAAB1QAAAAEUGf2kUVLBX/AAADAAADAA6ZAAAADwGf+XRBXwAAAwAAAwAOmAAAAA8Bn/tqQV8AAAMAAAMADpkAAAAXQZv9SahBbJlMCCv//rUqgAAAAwAAHVE=", e.load(), e.style.display = "none", e.playing = !1, e.play(), e.onplay = function () {
					this.playing = !0
				}, e.oncanplay = function () {
					e.playing ? (sessionStorage.autoplay_supported = "true", t(!0)) : (sessionStorage.autoplay_supported = "false", t(!1))
				}
			}
		},
		video_fallback_image: function () {
			typology_js_settings.cover_video_image_fallback && /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) && this.is_autoplay_supported(function (t) {
				t || (A(".typology-cover-img video").css("display", "none"), A(".typology-cover-img .typology-fallback-video-img").css("display", "block"))
			})
		},
		browser_check: function () {
			-1 !== navigator.appVersion.indexOf("MSIE 9.") && A("body").addClass("typology-ie9")
		},
		align_full_fix: function () {
			var t = "";
			A("body").hasClass("typology-flat") ? (t = ".alignfull { width: " + A(window).width() + "px; margin-left: -" + A(window).width() / 2 + "px; margin-right: -" + A(window).width() / 2 + "px; left:50%; right:50%;position: relative;max-width: initial; }", A("#typology-align-fix").length ? A("#typology-align-fix").html(t) : A("head").append('<style id="typology-align-fix" type="text/css">' + t + "</style>")) : (t = ".alignfull { max-width: " + A(".typology-section").outerWidth() + "px; width: 100vw; left:-" + (A(".typology-section").outerWidth() - A(".entry-content").outerWidth()) / 2 + "px; }", A("#typology-full-fix").length ? A("#typology-full-fix").html(t) : A("head").append('<style id="typology-full-fix" type="text/css">' + t + "</style>"))
		},
		search_action_hover: function (t) {
			A("body").on("click", ".typology-header .typology-search-form input[type=text]", function () {
				A(".typology-header .typology-action-search").addClass("search-action-active")
			});
			A("body").mouseup(function () {
				A(".typology-header .typology-action-search").removeClass("search-action-active")
			})
		}
	};
	A(document).ready(function () {
		g.init()
	}), A(window).resize(function () {
		g.resize()
	})
}(jQuery);