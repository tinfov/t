---
order: 1
pcx-content-type: navigation
---

# Status codes

We have many different status codes. They can be related to:

* [Custom hostnames](/ssl-for-saas/status-codes/custom-hostnames)
* [Specific certificate authorities](/ssl-for-saas/status-codes/certificate-authority-specific)
* [Custom Certificate Signing Requests](/ssl-for-saas/status-codes/custom-csrs)
