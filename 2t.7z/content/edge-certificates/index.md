---
order: 2
pcx-content-type: navigation
---

# Edge certificates

Learn more about SSL/TLS protection options for your edge certificates:

<DirectoryListing path="/edge-certificates"/>