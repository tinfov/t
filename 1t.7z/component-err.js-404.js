(window.webpackJsonp = window.webpackJsonp || []).push([
	[4], {
		w2l6: function(e, t, n) {
			"use strict";
			n.r(t);
			var a = n("q1tI"),
				l = n.n(a),
				o = n("07sb"),
				r = n("vrFN"),
				u = n("mT7v");
			t.default = function() {
				return l.a.createElement(l.a.Fragment, null, l.a.createElement(r.a, {
					title: "Not found"
				}), l.a.createElement("h1", null, "Not found"), l.a.createElement("p", null, "Unfortunately, the page you requested cannot be found."), l.a.createElement("p", null, l.a.createElement(o.a, {
					href: "/"
				}, "Go to ", l.a.createElement(u.a, null), " docs home")))
			}
		}
	}
]);