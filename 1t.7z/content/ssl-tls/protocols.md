---
order: 2
pcx-content-type: reference
---

# Protocols

Cloudflare supports the following TLS protocols:

* TLS 1.0
* TLS 1.1
* TLS 1.2
* TLS 1.3 ([recommended](https://www.cloudflare.com/learning/ssl/why-use-tls-1.3/))