---
title: Sponsorships
type: developers-site
---

import Stripe from "../components/stripe.js"
import Sponsorships from "../components/sponsorships/index.js"

<Stripe>

# Sponsorships

Cloudflare powers over 20 million Internet properties, including these world-changing open-source projects.

<!-- p><Button type="primary" href="#apply">Apply for sponsorship</Button></p -->

</Stripe>

<Sponsorships/>
