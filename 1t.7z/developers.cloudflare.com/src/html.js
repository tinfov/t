import html from "cloudflare-docs-engine/src/html.js"
export default html
