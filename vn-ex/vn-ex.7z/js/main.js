
var lastScrollTop = 0,
	action = "stopped",
	timeout = 1;
$.fn.scrollEnd = function (a, b) {
	$(this).scroll(function () {
		var c = $(this).scrollTop(),
			d = $(this);
		0 != lastScrollTop && (c < lastScrollTop ? action = "scrollUp" : c > lastScrollTop && (action = "scrollDown")), lastScrollTop = c, d.data("scrollTimeout") && clearTimeout(d.data("scrollTimeout")), d.data("scrollTimeout", setTimeout(a, b))
	})
}, $(window).scrollEnd(function () {
	"stopped" != action && $(document).trigger(action)
}, timeout);


$(document).ready(function () {
	VnExpress.init();
});
var homePage = [],
	isHomeActive = true,
	excludeId = [],
	VnExpress = {
		init: function () {
			var hash = window.location.href;
			this.removeEmptyComment();
			this.layout();
			this.share();
			this.interactionsParser("cmt.widget");
			if (typeof PAGE_DETAIL != "undefined" && PAGE_DETAIL == 1) {
				if (typeof VnExpress.resizeImageDetail != "undefined") {
					VnExpress.resizeImageDetail();
					$(window).resize(function () {
						VnExpress.delayFireOnce(1E3).done(function () {
							VnExpress.resizeImageDetail()
						})
					})
				}
				this.interactionsParser("comment");
				this.pinBar();
				this.history();
				$(".vne_equal_height").matchHeight();
				this.interactionBitly()
			} else {
				$(".exclude").each(function () {
					excludeId.push(parseInt($(this).attr("data-id")))
				});
				this.getCommentsByObject();
				this.activeContent();
				this.navigationUrl();
				this.paging()
			}
		},
		interactionBitly: function () {
			//
		},
		interactionsParser: function (action) {
            //
		},
		layout: function () {
			
			
			$(".btn_view_more a").click(function () {
				$(".info_text_au").toggleClass("expan_author");
				if ($(this).data("show") != 1) $(".btn_view_more a").data("show", 1).text("Thu g\u1ecdn");
				else $(".btn_view_more a").data("show", 0).text("Xem th\u00eam")
			});
			$(".sidebar_3").css("float", "right");
			$(document).on("scrollUp", function () {
				$("#topbar").removeClass("nav-up").addClass("nav-down");
				
				
				
				var sbo = $(".sidebar_1").attr("class");
				if (typeof sbo != "undefined" && sbo.indexOf("scroll-to-fixed-fixed") > -1) $(".sidebar_1, .sidebar_3 .box_category:last").css({
					"top": "50px"
				});
				if ($(this).scrollTop() < 50) $("#to_top").hide()
			});
			$(document).on("scrollDown", function () {
				if ($(this).scrollTop() > 50) {
					$("#to_top").show();
					$("#topbar").removeClass("nav-down").addClass("nav-up");
				}
			});
			$("#to_top").on("click", function () {
				$("html, body").animate({
					scrollTop: "0px"
				}, 800)
			});
			
			
			$(".navbar-toggle").on("click", function (event) {
				$(".toggle-icon").toggleClass("is-clicked");
				
				$('#site-nav').toggleClass('is-active');
				$('#topbar').toggleClass('is-active');
				
				$(".mask-content").toggleClass("mask-is-open").one("webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend");
			});
			
			
			$(".mask-content").on("click", function (event) {
				alert("a")
				if (!$(event.target).is(".navbar-toggle")) {
					$(".toggle-icon").removeClass("is-clicked");
					$(".mask-content").removeClass("mask-is-open");
					
				}
			});
			
			
			VnExpress.interactionsParser("like.widget");
			VnExpress.interactionsParser("vote.widget");
			VnExpress.interactionsParser("quote.widget");
			VnExpress.onResize();
			$(window).on("resize", function () {
				VnExpress.onResize()
			})
		},
		onResize: function () {
			var sidebar = $(".sidebar_3");
			if (typeof sidebar != "undefined") {
				var sidebarDisplay = sidebar.css("display"),
					sidebarCookie = $.cookie("sidebar_show");
				if (sidebarDisplay == "none" && (typeof sidebarCookie == "undefined" || sidebarCookie == 1)) {
					$.cookie("sidebar_show", 0, {
						expires: 365,
						path: "/"
					});
					window.location.reload()
				} else if (sidebarDisplay != "none" && (typeof sidebarCookie == "undefined" || sidebarCookie == 0)) {
					$.cookie("sidebar_show", 1, {
						expires: 365,
						path: "/"
					});
					window.location.reload()
				}
			}
		},
		showMoreContent: function (elm) {
			$(elm).parent().hide();
			$(elm).parent().next().show()
		},
		showLessContent: function (elm) {
			$(elm).parent().hide();
			$(elm).parent().prev().show()
		},
		cutTextComment: function (str) {
			var result = "";
			if (typeof str == "undefined") return result;
			var arrContent = str.toString().trim().split(" ");
			var totalWord = 50;
			if (arrContent.length > 60) {
				var sortContent = arrContent.splice(0, totalWord).join(" ") + " ... ";
				result = "                <p>" + sortContent + '                    <a href="javascript:;" onclick="VnExpress.showMoreContent(this);" class="icon_show_full_comment">                    </a>                </p>                <p style="display: none;">' + str + '                     <a href="javascript:;" onclick="VnExpress.showLessContent(this);" class="icon_show_full_comment icon_tru">                     </a>                </p>'
			} else result = "<p>" + str + "</p>";
			return result
		},
		getCommentsByObject: function () {
			$(".show_comment").each(function (index, elm) {
                //ajar
			})
		},
		cacheHome: function () {
			homePage["#moi_nhat"] = $(".sidebar_2").clone().wrap("<section>").parent().html()
		},
		removeEmptyComment: function () {
			setTimeout(function () {
				$(".icon_commend").each(function () {
					var display = $(this).css("display");
					if (display == "none") $(this).parents(".meta_post").find(".space_comment, .right").remove()
				});
				$(".icon_commend").on("click", function () {
					window.location.href = $(this).attr("data-href")
				})
			}, 1E3)
		},
		paging: function () {
			var paging = $("#paging"),
				url = paging.attr("data-url"),
				category_id = paging.attr("data-category"),
				exclude = paging.attr("data-exclude");
			paging.attr("data-working", 0);
			$(window).unbind("scroll.myScroll");
			$(window).bind("scroll.myScroll", function () {
				if ($(window).scrollTop() + $(window).height() >= $(document).height() - 85 && paging.attr("data-working") == 0) {
					paging.attr("data-working", 1);
					VnExpress.serverSide(url, category_id, exclude)
				}
			})
		},
		isLoaded: [],
		serverSide: function (url, category_id, exclude) {
			var page = $("#paging").attr("data-page"),
				rule = $("#paging").attr("data-rule"),
				html = "";
			var varjoin = category_id + "-" + rule + "-" + page;
			var numItems = $("#paging > .list_item").length || 0;
			if ($("#paging").attr("data-error") == 2 || isNaN(category_id) === true || $.inArray(varjoin, VnExpress.isLoaded) > -1) return false;
			if (typeof rule == "undefined") rule = 2;
			VnExpress.animateLoading($("#paging"), "show");
			VnExpress.isLoaded.push(varjoin);
			$.ajax({
				url: url.replace("tin-tuc/goc-nhin", "ajax/goc-nhin"),
				dataType: "json",
				data: {
					category_id: category_id,
					page: page,
					exclude: exclude,
					rule: rule
				},
				success: function (data) {
					$("#paging").attr("data-error", data.error);
					var currentUrl = window.location.href;
					currentUrl = currentUrl.split("#");
					if (typeof currentUrl[1] != "undefined" && parseInt(currentUrl[1]) == category_id) setTimeout(function () {
						homePage["#" + category_id] = $(".sidebar_2").clone().wrap("<section>").parent().html()
					}, 1100);
					if (data.message && data.error == 1) {
						$("#paging").attr("data-page", data.page);
						$.each(data.message, function (k, v) {
							if ($.inArray(parseInt(v.article_id), excludeId) < 0) {
								numItems += 1;
								var gaCode = "ga('t3.send', 'event', 'Stream', 'clk_Stream_" + numItems + ", 'HomeGocNhin')";
								html += '                            <article class="list_item clearfix">                                <div class="thumb_100">                                    <a href="' + v.share_url + '" class="thumb thumb_1x1" onclick="' + gaCode + ';">                                        <img src="' + v.images + '" alt="' + v.title_format + '" title="' + v.title_format + '">                                    </a>                                </div>                                <div class="content_item">                                    <h2 class="title_item"><a href="' + v.share_url + '" onclick="' + gaCode + ';">' + v.title_format + '</a></h2>                                    <p class="meta">                                        <span class="meta_author">' + v.meta_post + '<span class="icon_commend" data-href="' + v.share_url + '#box_comment" style="white-space: nowrap; cursor: pointer; display: none;"><span class="txt_num_comment font_icon" data-type="comment" data-objecttype="' + v.article_type + '" data-objectid="' + v.article_id + '"><img class="icon_content icon_title_coment" src="' + img_url + '/graphics/img_blank.gif">&nbsp;</span></span></span>                                    </p>                                    <p class="description">' + v.lead + "</p>                                </div>                            </article>"
							}
						});
						$("#paging").append(html);
						VnExpress.interactionsParser("cmt.widget");
						VnExpress.removeEmptyComment();
						VnExpress.tracking();
						VnExpress.deactiveMenu("disable");
						$("#paging").attr("data-working", 0)
					}
					VnExpress.animateLoading($("#paging"), "hide");
					VnExpress.paging()
				}
			})
		},
		tracking: function () {
			//
		},
		activeContent: function () {
			var href = $(".sidebar_1 ul li a");
			href.unbind("click");
			href.bind("click", function () {
				VnExpress.deactiveMenu("enable");
				$("html, body").animate({
					scrollTop: $(".sidebar_2").offset().top - 50
				}, 800);
				var catecode = $(this).attr("href");
				catecode = catecode.split("#");
				catecode = "#" + catecode[1];
				$(".sidebar_1 ul li, .sidebar_2 .content_nav a").removeClass("active");
				$(this).parent("li").addClass("active");
				$("#paging").attr("data-working", 0);
				VnExpress.streamData(catecode)
			});
			var breakcumb = $(".sidebar_2 .content_nav a, #topbar .content_nav a");
			breakcumb.unbind("click");
			breakcumb.bind("click", function () {
				VnExpress.deactiveMenu("enable");
				$("html, body").animate({
					scrollTop: $(".sidebar_2").offset().top - 50
				}, 800);
				var catecode = $(this).attr("href");
				catecode = catecode.split("#");
				catecode = "#" + catecode[1];
				$(".sidebar_1 ul li, .sidebar_2 .content_nav a, #topbar .content_nav a").removeClass("active");
				var classes = $(this).attr("data-class");
				$('a[data-class="' + classes + '"]').addClass("active");
				$("#paging").attr("data-working", 0);
				VnExpress.streamData(catecode)
			})
		},
		streamData: function (catecode) {
			//
		},
		navigationUrl: function () {
			//
		},
		isSticky: function (height) {
			$(window).unbind("scroll.isSticky");
			var sidebar_1 = $(".sidebar_1"),
				sidebar_3 = $(".sidebar_3 .box_category:last"),
				sidebar_1_top = sidebar_1.offset().top,
				sidebar_3_top = sidebar_3.offset().top,
				sidebar_1_width = sidebar_1.outerWidth(),
				sidebar_3_width = sidebar_3.outerWidth();
			$(window).bind("scroll.isSticky", function () {
				var isShowMenu = $("#topbar").attr("class").indexOf("nav-down") > -1 ? "50px" : "5px",
					obj = [sidebar_1, sidebar_3],
					objTop = [sidebar_1_top, sidebar_3_top],
					objWidth = [sidebar_1_width, sidebar_3_width];
				$.each(obj, function (k, v) {
					var breakEach = false;
					if ($(".sidebar_2").height() > $(".sidebar_1").height())
						if (k == 0) breakEach = true;
					if ($(".sidebar_2").height() > $(".sidebar_3").height())
						if (k == 1) breakEach = true;
					if (breakEach == true) {
						v.css({
							"top": isShowMenu
						});
						if ($(window).scrollTop() >= objTop[k] && typeof v.attr("class") != "undefined" && v.attr("class").indexOf("isSticky") < 0) {
							v.addClass("isSticky").css({
								"width": objWidth[k] + "px",
								"transform": "translate3d(0,0,0) !important",
								"position": "fixed",
								"z-index": 8009
							});
							if (k == 0) $("#topbar .content_nav").show()
						}
					}
					if ($(window).scrollTop() < objTop[k] && typeof v.attr("class") != "undefined" && v.attr("class").indexOf("isSticky") > -1) {
						v.removeClass("isSticky").removeAttr("style");
						if (k == 0) $("#topbar .content_nav").hide()
					}
				})
			})
		},
		animateLoading: function (element, action) {
			if (action == "show") {
				var loadHtml = "";
				for (i = 1; i <= 2; ++i) loadHtml += '<article class="list_item clearfix box_loading_2"><div class="thumb_100"><div class="box-line-thumb"></div></div><div class="content_item"><h2 class="title_item"><div class="box-line-title"></div></h2><div class="meta"><div class="box-line-author"></div></div><div class="description"><div class="box-line-desc-first"></div><div class="box-line-desc-second"></div></div></div></article>';
				element.append(loadHtml)
			} else element.find(".box_loading_2").remove();
			return true
		},
		pagingAuthor: function () {
            //
		},
		pagingAuthorNews: function () {
            //
		},
		pinBar: function () {
			var pin_bottom_content = $(".pin_bottom_content .owl-carousel");
			pin_bottom_content.owlCarousel({
				loop: false,
				autoplay: false,
				autoplayTimeout: 7E3,
				margin: 10,
				items: 6,
				responsive: {
					600: {
						items: 3
					},
					768: {
						items: 3
					},
					1024: {
						items: 3
					},
					1200: {
						items: 4
					},
					1367: {
						items: 5
					},
					1600: {
						items: 6
					}
				},
				slideBy: 3,
				pagination: false
			});
			pin_bottom_content.on("changed.owl.carousel", function (e) {
				$(".btn_prev, .btn_next").show();
				if (e.item.index + e.page.size >= e.item.count) $(".btn_next").show().fadeOut();
				if (e.item.index == 0) $(".btn_prev").show().fadeOut()
			});
			$(".btn_next").on("click", function () {
				pin_bottom_content.trigger("next.owl.carousel")
			});
			$(".btn_prev").on("click", function () {
				pin_bottom_content.trigger("prev.owl.carousel")
			});
			var pin = $(".pin_bottom_content"),
				pin_status = $.cookie("pin_bar");
			if (typeof pin_status != "undefined" && pin_status == "none") {
				pin.css("display", $.cookie("pin_bar"));
				$(".pin_bar_3 .more_text").text("Xem th\u00eam");
				$(".pin_bar_3 .ic").removeClass("ic-double-arrow-down").addClass("ic-double-arrow-up")
			}
			$(".pin_bar_3 a").on("click", function () {
				if (pin.css("display") != "none") {
					pin.show().fadeOut();
					setTimeout(function () {
						$(".pin_bar_3 .more_text").text("Xem th\u00eam");
						$(".pin_bar_3 .ic").removeClass("ic-double-arrow-down").addClass("ic-double-arrow-up")
					}, 300);
					$.cookie("pin_bar", "none", {
						expires: 7,
						path: "/"
					})
				} else {
					pin.hide().fadeIn();
					setTimeout(function () {
						$(".pin_bar_3 .more_text").text("Thu g\u1ecdn");
						$(".pin_bar_3 .ic").removeClass("ic-double-arrow-up").addClass("ic-double-arrow-down")
					}, 300);
					$.cookie("pin_bar", "block", {
						expires: 7,
						path: "/"
					})
				}
			});
			$(document).on("scrollUp", function () {
				var pin_group = ".pin_bottom";
				if (pin.css("display") != "none") pin_group = ".pin_bottom, .pin_bottom_content";
				$(pin_group).show().removeClass("pin-down").addClass("pin-up")
			});
			$(document).on("scrollDown", function () {
				var pin_group = ".pin_bottom";
				if (pin.css("display") != "none") pin_group = ".pin_bottom, .pin_bottom_content";
				$(pin_group).removeClass("pin-up").addClass("pin-down")
			})
		},
		history: function () {
            //
		},
		share: function () {
			$(".social_share").on("click", function () {
				var url = $(this).attr("data-url"),
					type = $(this).attr("data-type");
				if (typeof url != "undefined" && typeof type != "undefined")
					if (type == "facebook") {
						var linkFB = "https://www.facebook.com/sharer/sharer.php?u=" + url;
						window.open(linkFB, "_blank", "height=450,width=700,resizable=no,status=no")
					} else if (type == "twitter") {
					var shareContent = $(this).attr("data-content") + " - VnExpress " + url;
					shareContent = encodeURIComponent(shareContent);
					var linkTw = "https://twitter.com/intent/tweet?source=webclient&text=" + shareContent;
					window.open(linkTw, "_blank", "height=450,width=700,resizable=no,status=no")
				} else if (type == "google") {
					var linkGG = "https://plus.google.com/share?url=" + url;
					window.open(linkGG, "_blank", "height=450,width=550,resizable=no,status=no")
				}
			});
			return true
		},
		deactiveMenuTimeOut: 0,
		deactiveMenu: function (status) {
			var menu = $(".sidebar_1, .content_nav");
			if (status == "disable") {
				if (this.deactiveMenuTimeOut > 0) clearTimeout(this.deactiveMenuTimeOut);
				this.deactiveMenuTimeOut = setTimeout(function () {
					menu.css("pointer-events", "auto")
				}, 1E3)
			} else menu.css("pointer-events", "none");
			VnExpress.activeContent();
			return true
		},
		delayTimer: 0,
		delayFireOnce: function (timeout) {
			var d = $.Deferred();
			clearTimeout(VnExpress.delayTimer);
			VnExpress.delayTimer = setTimeout(function () {
				d.resolve()
			}, timeout);
			return d.promise()
		},
		resizeImageDetail: function (container, objwidth) {
			var tableObj = container ? $(container).find('table[class!="tbl_fptplay"]') : $('.fck_detail table[class!="tbl_fptplay"]');
			var width_global = 0;
			var pwidth = objwidth ? $(objwidth).width() : $(".fck_detail").width();
			var checkalign = function (obj, scale) {
				if ($(obj).attr("align")) switch ($(obj).attr("align")) {
				case "left":
					$(obj).css("margin-right", "10px");
					break;
				case "right":
					$(obj).css("margin-left", "10px");
					break
				}
				return scale
			};
			var fcondition1 = function (obj) {
				var img = new Image;
				img.onload = function () {
					var iwidth = img.width;
					if (iwidth > pwidth) $(obj).width("100%").parents("table").width("100%");
					else {
						var scale = iwidth / pwidth * 100;
						scale = checkalign($(obj).parents("table"), scale);
						$(obj).css("width", "").parents("table").width(scale + "%")
					}
					$(obj).attr({
						"data-width": iwidth,
						"data-pwidth": pwidth
					})
				};
				img.src = $(obj).attr("src")
			};
			var fcondition2 = function (obj) {
				var img = new Image;
				img.onload = function () {
					var iwidth = img.width;
					width_global = iwidth >= width_global ? iwidth : width_global;
					if (iwidth > pwidth) $(obj).width(pwidth);
					else $(obj).css("width", ""); if (width_global < pwidth) {
						var scale = width_global / pwidth * 100;
						scale = checkalign($(obj).parents("table"), scale);
						$(obj).parents("table").width(scale + "%")
					}
					$(obj).attr({
						"data-width": iwidth,
						"data-pwidth": pwidth
					})
				};
				img.src = $(obj).attr("src")
			};
			var fcondition3 = function (obj) {
				var img = new Image;
				img.onload = function () {
					var iwidth = img.width;
					$(obj).attr({
						"data-width": iwidth,
						"data-pwidth": pwidth
					});
					if (iwidth > pwidth) fcondition31(obj)
				};
				img.src = $(obj).attr("src")
			};
			var fcondition31 = function (obj) {
				if ($(obj).attr("data-width") > pwidth) $(obj).width("100%").parents("table").width("100%");
				else {
					var scale = $(obj).attr("data-width") / pwidth * 100;
					scale = checkalign($(obj).parents("table"), scale);
					$(obj).css("width", "").parents("table").width(scale + "%")
				}
			};
			var fcondition4 = function (obj, count_td) {
				var img = new Image;
				img.onload = function () {
					var iwidth = img.width;
					var td_width = pwidth / count_td;
					var scale = td_width / pwidth * 100;
					if (iwidth >= td_width) $(obj).width("100%").parents("td").width(scale + "%");
					$(obj).attr({
						"data-width": iwidth,
						"data-pwidth": pwidth
					})
				};
				img.src = $(obj).attr("src")
			};
			tableObj.each(function (i, o) {
				if ($(o).find('div[data-component="true"]').size() < 1 && $(o).parents('div[data-component="true"]').size() < 1) {
					$(o).removeAttr("width").find("img").css("height", "");
					var condition = $(o).find("tr").size() > 1;
					if (condition) {
						var count_img = count_td = 0;
						var condition1 = condition2 = false;
						$(o).find("tr").each(function () {
							count_td = $(this).find("td").size();
							$(this).find("td").each(function () {
								count_img += $(this).find("img").size();
								if ($(this).find("img").size() > 1) condition2 = true
							})
						});
						condition1 = count_img < 2;
						if (condition1) $(o).find("img").each(function () {
							fcondition1(this)
						});
						else if (condition2) $(o).find("img").each(function () {
							fcondition2(this)
						});
						else $(o).find("img").each(function () {
							fcondition4(this, count_td)
						})
					} else $(o).find("img").each(function () {
						fcondition3(this)
					})
				}
			})
		}
	};
    
    